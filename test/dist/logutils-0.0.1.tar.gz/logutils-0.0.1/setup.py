'''
Created on 07-Jun-2018

@author: psambyal
'''
from distutils.core import setup
#create distributed packages or modules

setup(name='logutils',
      version='0.0.1',
      descrption ='demo for log roll overs',
      author_email='abc@gmail.com',
      packages=['logutils'])